# Student 3369208 studied 3978,COMPA1 starting in 10s2
iphp progress 3369208 11s2
