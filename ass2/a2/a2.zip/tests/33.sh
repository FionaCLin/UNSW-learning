# Rule [10380] 12 UOC of General Education courses (under 3978)
# ... precludes Gen Ed courses offered within the Faculty of Engineering
# 3278837 studied 3978 in 08s1
php cansat COMP1911 10380 3278837 08s1
